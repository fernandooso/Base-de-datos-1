
package prueba2;

import java.sql.SQLException;
import java.util.Scanner;
public class Main {
    
    public static void main(String args[]) throws SQLException {
        Scanner in = new Scanner(System.in);
        menu unmenu = new menu();
        int op=4;
        while(op!=0){
            op=unmenu.muestra();      
            if(op==1){
                unmenu.alumno();
            }
            if(op==2){
                unmenu.apoderado();
            }
            if(op==3){
                unmenu.profesor();
            }
        }
    }  
}
