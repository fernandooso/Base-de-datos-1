
package prueba2;
import java.sql.*;
import javax.swing.JOptionPane;

public class conexion {

    static Connection conectar=null;
    static String BD="jdbc:postgresql://10.4.3.195:5432/colegio";
    static String usuario="colegio_dev";
    static String pass="aMgA5ka";
 
    public void conectpsql() {
        try {
            conectar =DriverManager.getConnection(BD,usuario,pass);
            //JOptionPane.showConfirmDialog(null,"conexion exitosa uwu");
        } catch (Exception e) {
            //JOptionPane.showConfirmDialog(null,"error al conectar "+e);
        }
    }   
    
    public void desconectar(){
        try {
            conectar.close();
            //JOptionPane.showConfirmDialog(null,"conexion cerrada");
        } catch (Exception e) {
        }
    }
    
    public void insertaralumno(String rut,String nombre,String s_nombre,String ap,String am,String dir,String sex,String fnac) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        String insert="insert into persona"+
                "(rut, nombre, nombre_s, apellido_p,apellido_m,direccion,sexo,f_nac)"+
                " values ('"+rut+"','"+nombre+"','"+s_nombre+"','"+ap+"','"+am+"','"+dir+"','"+sex+"','"+fnac+"');";        
        st.executeUpdate(insert);
        insert="insert into alumno(rut_alumno) values('"+rut+"')";
        st.executeUpdate(insert);
        st.close();
    }
    
    public void insertarapoderado(String rut,String nombre,String s_nombre,String ap,String am,String dir,String sex,String fnac,String tipo,String pupilo) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        String insert="insert into persona"+
                "(rut, nombre, nombre_s, apellido_p,apellido_m,direccion,sexo,f_nac)"+
                " values ('"+rut+"','"+nombre+"','"+s_nombre+"','"+ap+"','"+am+"','"+dir+"','"+sex+"','"+fnac+"');";     
        st.executeUpdate(insert);
        insert="insert into apoderado(rut_apoderado,tipo) values ('"+rut+"','"+tipo+"');";
        st.executeUpdate(insert);
        insert="insert into a_cargo(niño,apoderado,fecha_a_cargo)values('"+pupilo+"','"+rut+"','2021-03-01')";
        st.executeUpdate(insert);
        st.close();
    }
    public void insertarprofesor (String rut,String nombre,String s_nombre,String ap,String am,String dir,String sex,String fnac,String esp,String jef,String fejef) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        String insert="insert into persona(rut, nombre, nombre_s, apellido_p,apellido_m,direccion,sexo,f_nac) values ('"+rut+"','"+nombre+"','"+s_nombre+"','"+ap+"','"+am+"','"+dir+"','"+sex+"','"+fnac+"');";        
        st.executeUpdate(insert);
        insert="insert into profesor (rut_profesor, jefatura, especialidad, fecha_jefatura) values ('"+rut+"','"+jef+"','"+esp+"','"+fejef+"')";
        st.close();
    }
}
