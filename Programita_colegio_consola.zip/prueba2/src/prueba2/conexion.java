
package prueba2;
import java.sql.*;
import javax.swing.JOptionPane;

public class conexion {

    static Connection conectar=null;
    static String BD="jdbc:postgresql://10.4.3.195:5432/colegio";
    static String usuario="colegio_dev";
    static String pass="aMgA5ka";
 
    public void conectpsql() {
        try {
            conectar =DriverManager.getConnection(BD,usuario,pass);
        } catch (Exception e) {
        }
    }   
    
    public void desconectar(){
        try {
            conectar.close();
        } catch (Exception e) {
        }
    }
            

    
    public void insertaconsultasimple(String insert) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        st.executeUpdate(insert);
        st.close();
    }
    
    public void insertaconsultadoble(String insert1,String insert2) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        st.executeUpdate(insert1);
        st.executeUpdate(insert2);
        st.close();
    }
    public void insertaconsultatriple(String insert1,String insert2,String insert3) throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        st.executeUpdate(insert1);
        st.executeUpdate(insert2);
        st.executeUpdate(insert3);
        st.close();
    }
    
    public void consultanotas(String consulta) throws SQLException{
        Statement st= conectar.createStatement();
        ResultSet rs;
        try {
            rs=st.executeQuery(consulta);
            while(rs.next()){ 
               System.out.println("alumno:"+rs.getString("estudiante"));
               System.out.println("asignatura:"+rs.getString("materia"));
               System.out.println("nota:"+rs.getString("notas"));
               System.out.println("");
           }
        } catch (Exception e) {
            System.out.println("no pasa na compa");
        }
        st.close();
    }
    
        public void consultasistencia(String consulta) throws SQLException{
        Statement st= conectar.createStatement();
        ResultSet rs;
        try {
            rs=st.executeQuery(consulta);
            while(rs.next()){ 
               System.out.println("alumno:"+rs.getString("alumnoa"));
               System.out.println("curso:"+rs.getString("curso"));
               System.out.println("asistencia:"+rs.getString("asistencia"));
               System.out.println("fecha:"+rs.getString("fecha"));
               System.out.println("");
           }
        } catch (Exception e) {
            System.out.println("no pasa na compa");
        }
                
        st.close();
    }
        public void consultanotaciones(String consulta) throws SQLException{
        Statement st= conectar.createStatement();
        ResultSet rs;
        try {
            rs=st.executeQuery(consulta);
            while(rs.next()){ 
               System.out.println("alumno:"+rs.getString("anotado"));
               System.out.println("profesor:"+rs.getString("anotante"));
               System.out.println("anotacion:"+rs.getString("comentario"));
               System.out.println("tipo:"+rs.getString("tipo"));
               System.out.println("fecha:"+rs.getString("fecha"));
               System.out.println("");
           }
        } catch (Exception e) {
            System.out.println("no pasa na compa");
        }
                
        st.close();
    }
}

