
package prueba2;
import java.sql.*;
import javax.swing.JOptionPane;

public class conexion {

    static Connection conectar=null;
    static String BD="jdbc:postgresql://10.4.3.195:5432/colegio";
    static String usuario="colegio_dev";
    static String pass="aMgA5ka";
 
    public void conectpsql() {
        try {
            conectar =DriverManager.getConnection(BD,usuario,pass);
            JOptionPane.showConfirmDialog(null,"conexion exitosa uwu");
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null,"error al conectar "+e);
        }
    }   
    
    public void desconectar(){
        try {
            conectar.close();
            JOptionPane.showConfirmDialog(null,"conexion cerrada");
        } catch (Exception e) {
        }
    }
    
    public void insertardatardo() throws SQLException{
        Statement st=null;
        st= conectar.createStatement();
        String insert="insert into persona (rut, nombre, nombre_s, apellido_p, apellido_m,direccion,sexo,f_nac) values ('12345674-0','simon','richard','riley','smith','taske froce 141','h','1981-09-10');";
        st.executeUpdate(insert);
        st.close();
    }
}
