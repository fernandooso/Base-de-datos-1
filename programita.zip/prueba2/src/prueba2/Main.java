
package prueba2;

import java.sql.SQLException;

public class Main {
    
    public static void main(String args[]) throws SQLException {
        System.out.println("uuuuu");
        conexion con= new conexion();
        con.conectpsql();
        con.insertardatardo();
        con.desconectar();
    }  
}
